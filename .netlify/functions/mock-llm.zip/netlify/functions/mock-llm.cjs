var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/mock-llm.js
var mock_llm_exports = {};
__export(mock_llm_exports, {
  default: () => mock_llm_default
});
module.exports = __toCommonJS(mock_llm_exports);
var mock_llm_default = async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });
  const body = await req.json().catch(() => ({}));
  const msgs = body.messages || [];
  const last = [...msgs].reverse().find((m) => m.role === "user")?.content || "";
  const reply = `[Hack Scout mock demo] You asked: "${String(last).slice(0, 140)}". This network is running in your browser with the published mock router. For real answers, add your OpenAI-compatible key in AI model settings (BYOK) - it never leaves your browser.`;
  return new Response(JSON.stringify({ id: "mock-1", object: "chat.completion", choices: [{ index: 0, message: { role: "assistant", content: reply }, finish_reason: "stop" }] }), { status: 200, headers: { "Content-Type": "application/json", ...cors } });
};
var cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Methods": "POST,OPTIONS", "Access-Control-Allow-Headers": "Content-Type,Authorization" };
